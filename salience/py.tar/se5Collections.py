import saliencefive as SE5

# Define the path to Lexalytics root installation
LXA_HOME = 'C:/Program Files/Lexalytics'

def populateList():
    commentlist = []
    commentlist.append("The cruise was excellent and service from Princess was first class. Cruise lines should let people know that the on again off again tourist buses in the major cities are a very good tour and inexpensive. Our booking by our local Expedia agent Stuart Bustard was the best experience we have ever had. It was so well planned we had no worries at any time.",)
    commentlist.append("I found the temperature in the dining rooms very cold . Many passengers that we talked to seemed to agree. Otherwise the ship was very clean, comfortable and well maintained. The service and the food was excellent The outdoor movie theatre was a highlight for us.",)
    commentlist.append("The ship was beautiful and all facilities conveniently located from our stateroom. Crew members who served us were so helpful, pleasant and efficient making a big difference to our wellbeing. My husband's luggage had been lost owing to our flight being redirected midflight from Amsterdam to Paris as a result of the ash cloud and the purser got on to tracking it right away; the luggage fortunately arriving in Venice before we sailed. Our waiter was wonderful at making sure what was served to me did not adversely affect my food allergy. Our stateroom was comfortable, quite spacious, with a queen size bed and large window and every detail attended to by our capable room steward. We had been advised the room would have a restricted view owing to llifeboats but we found they did not restrict our viewing at all and we really appreciated being able to enjoy the scenery and port activity. This is our second Princess cruise and we certainly look forward to more trips with Princess. We took several tours, which were enjoyable except Istanbul. That tour did not go well taking two hours longer than scheduled as well as hitches along the way. I mentioned that at the tour desk and was given a form to complete, resulting in an immediate partial compensation for the cost and a well written letter apologising and advising the tour operator and Princess tour departments were copied to review that particular tour. Couldn't have been better handled. Overall a rewarding experience.",)
    commentlist.append("Very positive experience. Staff were very friendly and boarding, departure and tours were well organized. Although the ship was at full capacity it never seemed over crowded. The food and variety of meals offered was excellent. Would definetly cruise with Princess again.",)
    commentlist.append("Loved being on the 15th floor, near to the 24-hour buffet and swimming pools. The food was outstanding, the best we've had in our 5 cruises. Hated having to walk through the smokers poolside on our way to the buffet. Loved having a balcony to escape from the bustle of the ship. Was very impressed with the cleanliness of the ship. The service and friendliness of the staff, in particular, Christian, our steward, was phenomenal. Wish the selection of non-prescription medical products in the shop on board was larger. Better signage would have helped with the initial step of depositing luggage at embarkation in Venice. Once the luggage was deposited, the check-in process was the best we've experienced.",)
    commentlist.append("We enjoyed every aspect of this cruise - it was very well organized and thought out. Our stateroom with the balcony was certainly one of the highlights for us - we thoroughly enjoyed the relaxing atmosphere it created - right down to being able to have fresh coffee and cookies on our balcony, in the afternoons, while enjoying the sunshine and privacy. The dining rooms were beautiful, and menus varied and interesting, and the staff in the dining rooms were very accommodating and pleasant. We really can't think of anything that could be improved - it was a trip of a lifetime for us - and a very special way to celebrate our 50th wedding anniversary. The crew made this very special to us in recognizing our anniverary.",)
    commentlist.append("It is relaxing to have your room move with you. The ship was very comfortable and easy to move around. Internet service was poor and help not readily available Tours have too much shoping time and could have better opportunity to see more.",)
    commentlist.append("I saw so many beautiful sceneries in Europe and I think this was the best thing about my cruise. The most memorable thing about the ship was it was a big and comfortable ship almost brand new with an age of 2 yrs only.So far so good. Thank you.",)
    commentlist.append("best thing was the cruise staff - everyone was personable, helpful, friendly and fun - they couldn't have done anything more to help us most memorable thing about the ship was the ship itself; every square inch was grand and impressive and beautiful; overwhelming could be improved - service in the spa; the treatments i had were very inferior as to what i am used to",)
    commentlist.append("This was wonderful cruise! We enjoyed pretty much all aspects. The only black cloud was getting off the ship on the final day. We found some of the staff to be somewhat surly on that particular day, giving us the impression that because we were now departing the ship, they didn't have to be pleasant to us anymore. Also, it took over an hour from our appointed time to leave the ship to when we actually were able to leave due to customs issues. Then once we were in the customs area, it took another 70 minutes to get through customs to the dock! By this time, we were quite concerned that we would miss our flight home which caused us undo stress on our final vacaction day. Needless to say, this is definitely an area that needs to be improved.",)
    commentlist.append("Beautiful ship, great ports Most memorable thing - husband won Sexiest Legs on the Ruby Princess Improve service not as good as Celebrity, spa staff (front desk) were awful but the treatment staff were amazing ship is really large so there were lots of people. Hard to find dining tables, places to sunbath, etc. state room was very small",)
    commentlist.append("Enjoyed the ports of call. Cruise was well-organized, food (except for coffee) and service was excellent. Also enjoyed the entertainment. Improvements could be made in terms of flights - we had 3 flights for the return to Vancouver (flights were organized by Princess). With the wait times in between, it made for a very long day. Also, the coffee wasn't very good. If you wanted a good cup of coffee, you had to buy a coffee card.",)
    commentlist.append("The whole cruise was great. The only concern was that our upgraded suit had a much smaller balcony and our view was blocked by the front capitains bridge area. Everything else was wonderful exspecially the other guest such wonderful people.",)
    commentlist.append("It was a large ship with 3145 passengers and it never felt crowded. Excellent comedian on board entertainment. Very good entertainment and very good service in the traditional dining. It has a small ship feeling. Food was very good. Ports of call were also very good.",)
    commentlist.append("Dining service could be improved once our table asked for coffee 3x but we never got it. The servers didn't always understand English very well. The entertainment was good in the lounges and The shows were quite good I didn't really like the staff continually trying to sell things like pop and coffee cards and sparkling water at the dinner table. The food was quite good but a little too fancy for our taste.",)
    commentlist.append("We did enjoy most aspects of our cruise. First off, you need your \"buttons\" above to line up correctly under the categories. Many people will click on, for example, 4 thinking it is for \"good\", which is perfectly logical looking at the layout. I only figured it out when I was prompted for not responding on children's activities, thinking there was no button for n/a. Once I really looked at it, I could see the problem, but most people probably do these surveys quickly and will most likely click the button directly under the heading, unless they are choosing \"poor\" and automatically go to the far left. So maybe you're not doing as well as you thought. Felt some services were less than past experiences, due to automatic gratuities being added to our account, rather than being paid directly to the staff to encourage better service (particularly in the buffet). Had a very bad experience with the Passenger Services desk, when my room key became demagnitized. The rep was very annoyed with me and claimed it must have been my fault, almost implying I had done it intentionally. AFTER I had purchased some of the ship photos (which are non-returnable once purchased), enquired about whether 5x7's were available, as didn't particularly want 8x10, but it appeared to be the only choice. Was informed I could have purchased the digital file for significantly less and printed whatever size I wanted. If this information was posted anywhere, it wasn't particularly obvious, and was not volunteered by any of the photography staff. Was upset that my soda card was not accepted at Princess Cays, as I understood this was basically just an extension of the ship. Would like to see the soda card include free unlimited juices, as was the case on Royal Caribbean two years previously (had assumed this card would be the same). The Ruby Princess did not offer decaffeinated colas, so the card was not much use to me in the evenings.",)
    commentlist.append("I think the thing they can improve is having the gym open 24 hours or at least 5:00 am. 7:00 am does not let you have much time when you are doing things on islands early. Every trip we have been on has late gym openings.That is why I put poor for spa/fitness. I loved the entertainment and meeting new friends. I loved the middle of the ship with the great stairway. If you need anything you only have to ask.",)
    commentlist.append("The ship is beautiful - a little on the big side, but once you find your way around, its a piece of cake! They have lots of variety as far as eating - you have the traditional dining rooms (anytime or assigned), the buffets, specialty restaurants, Piazza, International Cafe....and the Pizza by the pool was to die for - best pizza I've had in a long time! We especially liked \"MUTS\" (Movie Under The Stars) and spent most of our daytime there relaxing watching the movies and swimming. Didn't see too many of the shows, as we spent a lot of time in the Casino - just wish they would have more \"non-smoking\" nights for us non-smokers - but the couple comedian's we saw were hilarious. This was the first time we have travelled with our son, who is 9. He spent the majority of his time in the Kids Club - we hardly ever saw him!! I knew they must have been doing something right, because he'd always want to be there right when they opened, and would quickly eat breakfast or dinner so he coudl be \"first\"! Even when they were closed for the couple of hours at lunch, he was busy swimming or hanging out with his new friends. I can't say enough about Princess's staff - they were more than accommodating - especially with our son - anything he asked for, they did their very best to get it for him....even \"warmed\" his cookies for him - can you say spoiled!! We would definitely take this cruise again - just enough stops to keep my shopping habit happy, and enough sea days for total relaxation!",)
    commentlist.append("Having adjoining balconies being open when travelling with others was a bonus. Personalities and professional attentiveness of dining room staff enhance trip. Information from Princess Inconsistent: i.e. mustering & exiting instructions done extremely well; staff evaluation surveys gave conflicting information. Inconsistent application of Dress Codes at Specialty restaurants (depends on who was at the door). Would prefer cruises with less ports & more at sea days.",)
    commentlist.append("Overall a good trip. As this is a very large ship, lines were an issue as well as the need to go very early for the various entertainment programs.(e.g. 30 - 40 minutes) Next time we will book a trip that uses smaller ships - fewer people - smaller lines etc. As usual, the Princess crew was excellent. Very attentive and willing to go the extra mile for you.",)
    commentlist.append("What I enjoyed the most about my cruise was visiting the private Princess Island in Bahamas. It was so beautiful and I didn't want to leave. We booked a beach house there and went on a banana boat ride, so our day was unforgettable. The thing I enjoyed most on the cruise was the entertainment and the food. I also would send out kudos to our cabin steward who was always so cheerful and helpful. The entire staff on this cruise were incredible. The movies under the stars was also a highlight, this is truly an experience. The only suggestion I would make would be for them to put alarm clocks in the rooms (next time I'll bring my own). Overall, the cruise was AWESOME, can't wait to go again.",)
    commentlist.append("Definitely need to improve on the quality of the food. My husband & I have been cruising with Princess since November 2004 - we are now Platium members and we were extremely disappointed with the food on the Ruby. The food was not as tasty as in the past. There is very few choices for those who do not eat meat. It definitely appeared that the cruise line was cutting back and it did with respect to the quality and choice of food. The experience was just not there this time round. Need more creativity in this area - this is were Princess can gain its competitive advantage and differeniate itself from other cruise lines. In Princess Cays we were unable to eat anything as most of the choices was meat based. Nevertheless, the dining service was excellent.The waiters tried to accomodate us as best they could with respect to the choices at hand.",)
    commentlist.append("Everything about the cruise was fantastic. The cruise staff are absolutely amazing. It was almost as if they could read your mind ... they knew what you needed before you even had to ask. Although the days at port are exciting and interesting, the days at sea are fantastic. Relaxing on the balcony with a glass of wine watching the whales is a great way to spend a vacation. What could be better! This was my third cruise and I have not yet found one thing that required improvement of any kind. Already planning our next cruise for 2012.",)
    commentlist.append("The best cruise we've been on, great weather, ship staff and crew were terrific, all as expected from this cruise line based upon past experiences. one item - based upon past experiences and other tours ------ - we booked a beach tour in St Lucia that was cancelled, and not replaced by an equal tour, thus we had to book another tour that was more expensive but reported as much better.-- it was pleasant, the beach was very nice however, this tour was definitely not worth the cost, as everything including refreshments was ala cart, if you varied from the lunch menu - ie not wanting the fish or chicken but perhaps the burger it was charged for, extra pop was charged for etc at the beach site - we were offered a glass of water on the outgoing but no other refreshments, and there was no offerings on the return ride - we weren't advised that there was even the availability of a bar or cold drinks - these have always been offered on other tours, and mostly gratis. - the crew was pleasant enough but we've had more interaction on other tours that were far less costly - I would expect this tour should be about 50% of the cost.",)
    commentlist.append("Loved the movies on deck at night with popcorn, warm milk and cookies. On-board entertainment was excellent. Was very disappointed that we couldn't dock at Curacao. Felt that cruise line should have made up for it in some way, either via an on-board credit or a credit toward the next cruise. Didn't need another \"day at sea.\" Poor PR on cruise line's part.",)
    commentlist.append("Everything runs smoothly on Princess Lines. The entertainment was not as good as usual but still very good. We were seated with excellent people in the dining room. Our dining room steward and room steward were very good. The only complaint was the cost of photographs. It has gone up considerably. $24.95 for one picture.",)
    commentlist.append("Loved visiting the islands and sharing this experience with life long friends. Sitting on the balcony drinking some wine and watching the world go by. Fantastic. Everyone was so helpful and considerate . We felt like Queens, or like one of the stewards call us the Spice Girls!!!!!! Great time.",)
    commentlist.append("The best thing about the cruise was the quality of the staff on board , from the Capt. down to the state room staff and especially the Botticelli dining room staff Oleg & Csaba took great care of our needs every evening and made our trip most enjoyable . The cleanliness of the ship and the constant care being taken to ensure that the deck was clean & dry as possible I think the Ruby is doing just fine as it is , allthough I did hear some negative remarks from some people but I saw the same people disparaging the Purser in a loud obnoxious voice.",)
    return commentlist

def demo():
	print 'Initializing'
        print SE5.getVersion()

	session = SE5.openSession(LXA_HOME+'/license.v5',LXA_HOME+'/data')
	
	#Prepare the text.  This is done once and then you can carry
	#out multiple operations on the same document
	print 'Preparing the Collection...'
        lstContent = populateList()
        ret = SE5.prepareCollectionFromList(session, "demo_collection", lstContent)
	#ret = SE5.prepareCollectionFromFile(session,"c:/test/collection.txt")
	if ret == 0:
		print '\nNamed Entities:' 
		# Get the entities
		entitylist = SE5.getCollectionEntities(session)
		print 'There are %i entities' % len(entitylist)
		for entity in entitylist:
			print '%s' %entity["normalized"],
			print ': %s' %entity["type"]
			print 'Sentiment:\t POS=%s' %entity["positive_hits"],
			print '\t NEG=%s' %entity["negative_hits"],
			print '\t NEU=%s' %entity["neutral_hits"]

		print '\nFacets:' 
		# Get the facets
		facetlist = SE5.getCollectionFacets(session)
		print 'There are %i facets' % len(facetlist)
		for facet in facetlist:
			print '%s' %facet["facet"],
			print ': %s mentions' %len(facet["mentions"])
			print 'Sentiment:\t POS=%s' %facet["positive_hits"],
			print '\t NEG=%s' %facet["negative_hits"],
			print '\t NEU=%s' %facet["neutral_hits"]
			
		print '\nCollection Themes:'
		# Get the themes
		# These are returned as a list of dictionaries
		themelist = SE5.getCollectionThemes(session)
		for theme in themelist:
			print '%s' %theme["theme"],
			print ' (%f)' %theme["score"]
			print ' \tSentiment: (%f)' %theme["sentiment"]
        
		print '\nQuery-defined Topics (based on sample file in data directory):'
		#Get Query-defined topics
		ret = SE5.setOption_QueryTopicList(session,LXA_HOME+'/data/salience/tags/sampletags.dat')
		if ret==0:
                    topiclist = SE5.getCollectionQueryDefinedTopics(session)
                    for topic in topiclist:
			print '%s' %topic["topic"],
			print ': %i hits,' %topic["hits"],
			print ' Sentiment score: %f' %topic["score"]

		print '\nConcept-defined Topics (based on sample file in data directory):'
		#Get Concept-defined topics
		ret = SE5.setOption_ConceptTopicList(session,LXA_HOME+'/data/salience/concepts/example.dat')
		if ret==0:
                    conceptlist = SE5.getCollectionConceptDefinedTopics(session)
                    for concept in conceptlist:
			print '%s' %concept["topic"],
			print ': %i hits,' %concept["hits"],
			print ' Match score: %f' %concept["score"]
			
	#Close the session down.  You shouldn't use the session object after making this call
	#Its important to note that if you let the sesssion go out of scope this it will automatically
	#call closeSession
	print '\nClosing session'
	ret = SE5.closeSession(session)

	print 'Finished'

if __name__ == "__main__":
	demo()
