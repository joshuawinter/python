#!/usr/bin/python



import os, subprocess, csv, sys

lparfile = csv.reader(open('lpars.cfg', 'rU'), delimiter='\t')
cfgfile = open('lparconf.cfg','w')


for lines in lparfile:
	try:
		env = lines[0]
		lpar = lines[1]
		#if env != None:
		if env == 'PERF':
			#print env + ' ' + lpar
			cmd = "nexec " + lpar + " lparstat -i"
			#print cmd
			p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
			cmdout, err = p.communicate()
			cfgfile.writelines('Environment' + '\t' + env + '\n')
			cfgfile.writelines(cmdout.replace(': ','\t') + '\n')
	except:
		print '\n'
		#print "Unexpected error:", sys.exc_info()[0]
cfgfile.close()




